
var CDate = new Date();
var today = new Date();
var selectCk = 0;

buildHeader();
buildcalendar();

function buildHeader(){
	//console.log("buildHeader() called");
	
    document.getElementById("year").innerHTML = CDate.getFullYear() + "년";
	document.getElementById("month").innerHTML = (CDate.getMonth() + 1) + "월";
}

function buildcalendar(){
	// console.log("buildcalendar() called");

	var prevLast = new Date(CDate.getFullYear(), CDate.getMonth(), 0); //전월 마지막날
	var thisFirst = new Date(CDate.getFullYear(), CDate.getMonth(), 1); //금월 첫날
	var thisLast = new Date(CDate.getFullYear(), CDate.getMonth() + 1, 0); //금월 마지막날
	
	const dates = []; //달력에 뿌려줄 날짜 담을 배열 준비
	if(thisFirst.getDay()!=0){ //금월 첫날이 일요일이 아니라면
		for(var i = 0; i < thisFirst.getDay(); i++){
			dates.unshift(prevLast.getDate()-i);
		} //첫날 요일 이전 요일의 전월 날짜(숫자i)들을 배열의 앞부터 추가
	}
	for(var i = 1; i <= thisLast.getDate(); i++){
		dates.push(i);
	} //마지막날 요일까지 날짜(숫자i)들을 배열에 차례대로 추가
	for(var i = 1; i <= 13 - thisLast.getDay(); i++){
		dates.push(i);
	} //마지막날 이후 다음 일요일까지의 익월 날짜(숫자i)들을 배열에 차례대로 추가
	// console.log("thisLast.getDay() : ", thisLast.getDay());
	// dates.forEach((item)=>{console.log(item)});

	var htmlDates = ''; //달력 뿌려줄 html 담을 문자열 준비
	for(var i = 0; i<42; i++){ //7일*6줄
		if(i < thisFirst.getDay()){ //전월 구간
			htmlDates += '<div class="date last">'+dates[i]+'</div>';
		}else if(today.getDate()==dates[i] && today.getMonth()==CDate.getMonth() 
				&& today.getFullYear()==CDate.getFullYear()){
			//오늘=해당 칸 && 오늘=금월 && 오늘=금년 일 때 (즉 오늘)
			htmlDates += '<div id="date_'+dates[i]+'" class="date today" onclick="fn_selectDate('
					+dates[i]+');">'+dates[i]+'</div>';
		}else if(i >= thisFirst.getDay() + thisLast.getDate()){
			//첫날 요일 + 마지막날 요일 합 보다 큰 칸 (즉 익월 구간)
			htmlDates += '<div class="date next">'+dates[i]+'</div>';
		}else{ //나머지 (즉 오늘 이외 금월 구간)
			htmlDates += '<div id="date_'+dates[i]+'" class="date" onclick="fn_selectDate('
					+dates[i]+');">'+dates[i]+'</div>';
		}
	}
// console.log("htmlDates : ",htmlDates); // htmlDates -> test.txt
document.getElementById("dates").innerHTML = htmlDates;	
}

function preCal(){ //[<] 클릭시 : 전월 달력 띄우기
	CDate.setMonth(CDate.getMonth()-1);
	buildcalendar();
}

function nextCal(){ //[>] 클릭시 : 익월 달력 띄우기
	CDate.setMonth(CDate.getMonth()+1);
	buildcalendar();
}

function fn_selectDate(date){ //금월 구간 클릭시
	var year = CDate.getFullYear();
	var month = CDate.getMonth() + 1;
	var date_txt = "0" + date;
}
if(selectCk == 0){
	// $(".date").CSS("background-color", "red");
	// $(".date").CSS("color", "");
	// $("#date_" +date).CSS("background-color", "red");
	// $("#date_"+date).CSS("color","white");
	// $("#period_1").val(year+"-"+month+"-"+date);
	// $("#period_2").val("");
	// ---위 jQuery 코드 아래에 풀어씀.--------------
	
	let element = document.getElementById("dates");
	let elements = element.getElementsByClassName("date");
	let len = elements.length;
    for (let i = 0; i < len; i++){
       elements.item(i).style.backgroundColor="red";
	   elements.item(i).style.color="";
    }
	document.getElementById("date_"+date).style.backgroundColor = "red";
	document.getElementById("date_"+date).style.color = "white";
	document.getElementById("period_1").value = year+"-"+month+"-"+date;
	document.getElementById("period_2").value = "";
	// ---위 jQuery 코드 아래에 풀어씀.끝.-------------
	selectCk = date;
}else{
	// $("date_"+date).CSS("background-color", "red");
	// $("date_"+date).CSS("color","white");
	// for(var i = selectCk + 1 ; i < date ; i++){
	// 	$("#date_"+i).CSS("background-color","#FFDDDD");
	// }
	// $("#period_2").val(year+"-"+month+"-"+date);
	// ---위 jQuery 코드 아래에 풀어씀.--------------
	element.getElementsByClassName("date_"+date).style.backgroundColor = "red";
	element.getElementsByClassName("date_"+date).style.color = "white";
	for(var i=selectCk+1 ; i < date ; i++){
		document.getElementById("date_"+i).style.backgroundColor = "#FFDDDD";
	}
	document.getElementById("period_2").value = year+"-"+month+"-"+date;
	// ---위 jQuery 코드 아래에 풀어씀.끝.-------------
	selectCk = 0;
}
